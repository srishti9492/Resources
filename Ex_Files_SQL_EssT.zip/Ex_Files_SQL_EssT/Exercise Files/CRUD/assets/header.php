<html>
<head>
    <link rel="SHORTCUT ICON" href="assets/bw.ico">
    <link REL="STYLESHEET" TYPE="text/css" HREF="css/main.css">
    <title> <?php echo $CRUD["TITLE"] ?> </title>
</head>
<body>
<div class="title_area">
    <table class="title_area"><tr>
    <td><p> <a class="title" href="<?php $CRUD["SELF"] ?>">CRUD</a> </p></td>
    <td class="subtitle"><p class="subtitle">
        Create Read Update Delete <br />
        by Bill Weinman
    </p></td>
    </tr></table>
</div>

