<html>
<head>
    <meta charset="UTF-8">
    <link rel="SHORTCUT ICON" href="assets/bw.ico">
    <link REL="STYLESHEET" TYPE="text/css" HREF="css/main.css">
    <title> <?php echo $SID["TITLE"] ?> </title>
</head>
<body>
<div class="title_area">
    <table class="title_area"><tr>
    <td class="title"><p class="title"> SID </p></td>
    <td class="subtitle"><p class="subtitle">
        SQL Interactive Demonstrator<br />
        by Bill Weinman
    </p></td>
    </tr></table>
</div>

