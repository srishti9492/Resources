
<div class="footer">
<p class="copyright">
    <?php echo $SID['DBVERSION'] ?>
    &middot;
    SID Version <?php echo VERSION ?>
    <br />
    Copyright &copy; 2009-2013 The BearHeart Group LLC
</p>

</body>
</html>
