﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// What’s POLYMORPHISM? 
/// It’s when classes have different functionality while sharing the same interface.
/// REMEMBER TO NOTE!!!: Interfaces or abstract classes can be used
/// </summary>
namespace PolymorphismDemo
{

    public class Program
    {
        private static void Main(string[] args)
        {
            //TODO
        }
    }
}
